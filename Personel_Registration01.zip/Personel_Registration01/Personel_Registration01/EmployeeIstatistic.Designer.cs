﻿namespace Personel_Registration01
{
    partial class EmployeeIstatistic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.LblToplamPersonel = new System.Windows.Forms.Label();
            this.Lbl_Married = new System.Windows.Forms.Label();
            this.LblMarried = new System.Windows.Forms.Label();
            this.Lbl_Single = new System.Windows.Forms.Label();
            this.LblSingle = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.LblCities = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.LblTotalSalary = new System.Windows.Forms.Label();
            this.LblAverageSalary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total number of Employee:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblToplamPersonel
            // 
            this.LblToplamPersonel.AutoSize = true;
            this.LblToplamPersonel.Location = new System.Drawing.Point(390, 97);
            this.LblToplamPersonel.Name = "LblToplamPersonel";
            this.LblToplamPersonel.Size = new System.Drawing.Size(20, 24);
            this.LblToplamPersonel.TabIndex = 1;
            this.LblToplamPersonel.Text = "0";
            // 
            // Lbl_Married
            // 
            this.Lbl_Married.AutoSize = true;
            this.Lbl_Married.Location = new System.Drawing.Point(180, 156);
            this.Lbl_Married.Name = "Lbl_Married";
            this.Lbl_Married.Size = new System.Drawing.Size(170, 24);
            this.Lbl_Married.TabIndex = 2;
            this.Lbl_Married.Text = "Married Employee:";
            this.Lbl_Married.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblMarried
            // 
            this.LblMarried.AutoSize = true;
            this.LblMarried.Location = new System.Drawing.Point(390, 156);
            this.LblMarried.Name = "LblMarried";
            this.LblMarried.Size = new System.Drawing.Size(20, 24);
            this.LblMarried.TabIndex = 3;
            this.LblMarried.Text = "0";
            // 
            // Lbl_Single
            // 
            this.Lbl_Single.AutoSize = true;
            this.Lbl_Single.Location = new System.Drawing.Point(193, 215);
            this.Lbl_Single.Name = "Lbl_Single";
            this.Lbl_Single.Size = new System.Drawing.Size(157, 24);
            this.Lbl_Single.TabIndex = 4;
            this.Lbl_Single.Text = "Single Employee:";
            this.Lbl_Single.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblSingle
            // 
            this.LblSingle.AutoSize = true;
            this.LblSingle.Location = new System.Drawing.Point(390, 215);
            this.LblSingle.Name = "LblSingle";
            this.LblSingle.Size = new System.Drawing.Size(20, 24);
            this.LblSingle.TabIndex = 5;
            this.LblSingle.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(197, 278);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(153, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Number of cities:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblCities
            // 
            this.LblCities.AutoSize = true;
            this.LblCities.Location = new System.Drawing.Point(390, 278);
            this.LblCities.Name = "LblCities";
            this.LblCities.Size = new System.Drawing.Size(20, 24);
            this.LblCities.TabIndex = 7;
            this.LblCities.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(224, 328);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Total Salary:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(197, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(142, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "Average Salary:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblTotalSalary
            // 
            this.LblTotalSalary.AutoSize = true;
            this.LblTotalSalary.Location = new System.Drawing.Point(390, 328);
            this.LblTotalSalary.Name = "LblTotalSalary";
            this.LblTotalSalary.Size = new System.Drawing.Size(20, 24);
            this.LblTotalSalary.TabIndex = 10;
            this.LblTotalSalary.Text = "0";
            // 
            // LblAverageSalary
            // 
            this.LblAverageSalary.AutoSize = true;
            this.LblAverageSalary.Location = new System.Drawing.Point(390, 369);
            this.LblAverageSalary.Name = "LblAverageSalary";
            this.LblAverageSalary.Size = new System.Drawing.Size(20, 24);
            this.LblAverageSalary.TabIndex = 11;
            this.LblAverageSalary.Text = "0";
            // 
            // EmployeeIstatistic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(685, 443);
            this.Controls.Add(this.LblAverageSalary);
            this.Controls.Add(this.LblTotalSalary);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.LblCities);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.LblSingle);
            this.Controls.Add(this.Lbl_Single);
            this.Controls.Add(this.LblMarried);
            this.Controls.Add(this.Lbl_Married);
            this.Controls.Add(this.LblToplamPersonel);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EmployeeIstatistic";
            this.Text = "EmployeeIstatistic";
            this.Load += new System.EventHandler(this.EmployeeIstatistic_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblToplamPersonel;
        private System.Windows.Forms.Label Lbl_Married;
        private System.Windows.Forms.Label LblMarried;
        private System.Windows.Forms.Label Lbl_Single;
        private System.Windows.Forms.Label LblSingle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label LblCities;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label LblTotalSalary;
        private System.Windows.Forms.Label LblAverageSalary;
    }
}